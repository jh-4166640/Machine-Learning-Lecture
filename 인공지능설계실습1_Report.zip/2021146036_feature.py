import numpy as np
import os
import cv2

# 많이 느립니다!
# 멈춘거 아닙니다!
# 되는거 확인했습니다.
# 제 노트북으로 15분넘게 걸렸습니다.

def MostColor(img):
    threshold = 220
    mask = np.all(img>threshold, axis=2)
    only_obj=img[~mask]
    obj = only_obj.reshape(-1,3)
    unique, counts = np.unique(obj, axis=0, return_counts=True)
    dominant = unique[np.argmax(counts)]
    return dominant
    
def Projection_COLUMN(img):
    threshold = 220
    mask = np.all(img>threshold, axis=2)
    
    col_sum = np.sum(~mask, axis=0)
    all_sum = np.sum(col_sum)
    pdf = col_sum / all_sum
    xx = np.arange(0,pdf.shape[0],1)
    exp = sum(xx*pdf)
    var = sum((xx-exp)**2*pdf)
    return 1/var # 그냥 var로 하면 overflow 발생해서 역수로 입력

def Projection_ROW(img):
    threshold = 220
    mask = np.all(img>threshold, axis=2)
    
    row_sum = np.sum(~mask, axis=1)
    all_sum = np.sum(row_sum)
    pdf = row_sum / all_sum
    xx = np.arange(0,pdf.shape[0],1)
    exp = sum(xx*pdf)
    var = sum((xx-exp)**2*pdf)
    return 1/var

def select_features(directory):
    K=3
    # 폴더 내 파일명 read
    file_list = os.listdir(directory)
    feature_1_list = []
    feature_2_list = []
    feature_3_list = []
    feature_4_list = []
    feature_5_list = []
    feature_6_list = []

    labels = []

    for name in file_list:
        path = os.path.join(directory, name)
        labels.append(int(name.split('_',1)[0]))
        # 이미지 Read & RGB 변환
        img_GRB = cv2.imread(path)
        img_RGB = cv2.cvtColor(img_GRB, cv2.COLOR_BGR2RGB)
        feature_1 = Projection_ROW(img_RGB)
        feature_2 = Projection_COLUMN(img_RGB)
        feature_3 = img_RGB[:,:,0].mean() # Red 평균 밝기
        feature_4 = img_RGB[:,:,1].mean() # Green 평균 밝기
        feature_5 = img_RGB[:,:,2].mean() # Blue 평균 밝기
        feature_6 = MostColor(img_RGB)
        
        
           
        feature_1_list.append(feature_1)
        feature_2_list.append(feature_2)
        feature_3_list.append(feature_3)
        feature_4_list.append(feature_4)
        feature_5_list.append(feature_5)
        feature_6_list.append(feature_6)
        

    feature_1_list = np.array(feature_1_list)
    feature_2_list = np.array(feature_2_list)
    feature_3_list = np.array(feature_3_list)
    feature_4_list = np.array(feature_4_list)
    feature_5_list = np.array(feature_5_list)
    feature_6_list = np.array(feature_6_list)
    
    features = np.column_stack([feature_1_list,feature_2_list,feature_3_list,feature_4_list,feature_5_list, feature_6_list])
    return features, labels


# 많이 느립니다!
# 멈춘거 아닙니다!
# 되는거 확인했습니다.
# 제 노트북으로 15분넘게 걸렸습니다.

